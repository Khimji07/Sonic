#pragma once

#include <string>

namespace swss {

std::string getTimestamp();

}
