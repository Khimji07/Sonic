#pragma once

// SAL annotations file

#define _In_
#define _Out_
#define _Inout_
